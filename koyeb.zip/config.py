BOT_TOKEN = "YOUR_BOT_TOKEN"
ADMIN_ID = 123456789  # Replace with your Telegram ID
WEBHOOK_URL = "https://your-koyeb-app-url.koyeb.app"  # Replace with your Koyeb app URL